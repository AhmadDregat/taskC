
#include "List.h"

Node* createNode(int data)
{
	Node* newNode = malloc(sizeof(Node));
	newNode->nextNode = NULL;
	newNode->data = data;
	return newNode;
}

Node* addNode(Node* head, Node* newNode)
{
	if (head != NULL) {
		newNode->nextNode = head;
		return newNode;
	}

	return NULL;
}

int addTail(Node* head, Node* newNode)
{

	if (head != NULL) {
		Node* temp = head;
		while(temp->nextNode != NULL)
			temp = temp->nextNode;

		temp->nextNode = newNode;

		return 1;
	}

	return 0;
}

