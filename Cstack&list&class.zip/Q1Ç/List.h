#ifndef LIST_H_
#define LIST_H_

#include <stdio.h>
#include <stdlib.h>

typedef struct Node{
	struct Node* nextNode;
	int data;
}Node;
Node* createNode(int data);

Node* addNode(Node* head, Node* newNode);

int addTail(Node* head, Node* newNode);
#endif 