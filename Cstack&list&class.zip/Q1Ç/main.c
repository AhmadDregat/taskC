
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
 
int numNodes = 0;
Node* mid = NULL;
Node* head;

int take(int num){

	numNodes++;

	if(head == NULL)
		head = createNode(num);
	else
	{
		Node* newNode = createNode(num);
		addTail(head,newNode);
	}

	if(mid == NULL)
		mid = head;

	if(numNodes % 2 == 0)
		mid = mid->nextNode;

	return mid->data;
}
int main(void) {

	for(int i = 5; i <45; i++)
	{
	  if(i%5==0){
		printf("take( %d).\n >> %d.\n",i, take(i));
	}
}
	puts("\n");
	return 0;
}
