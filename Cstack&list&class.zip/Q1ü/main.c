
#include <stdio.h>
#include <stdlib.h>

int* arr = NULL;
int countelements = 0;

void addData(int data)
{
	countelements++;

	if(arr == NULL)
		arr = (int*)malloc(countelements * sizeof(int));
	else
	{
		arr = (int*)realloc(arr,countelements * sizeof(int));
	}

	arr[countelements - 1] = data;
}

int cmpfunc (const void * a, const void * b) {
	return ( *(int*)a - *(int*)b );
}

void quickSort(int* arr,int size)
{
	qsort(arr, size, sizeof(int), cmpfunc);
}

int take2(int data)
{
addData(data);

	quickSort(arr,countelements);

	int median = arr[(int)(countelements/2)];

	return median;
}

int main(void) {

	for(int i =0; i <=10; i++)
	{
		printf("take2(%d).\n The new median is: %d.\n",i, take2(i));
	}

	puts("\n");

	
	return EXIT_SUCCESS;
}