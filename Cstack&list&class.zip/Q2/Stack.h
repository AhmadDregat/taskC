#ifndef STACK_H_
#define STACK_H_

#include <stdio.h>
#include <stdlib.h>

typedef struct Node{
	struct Node* nextNode;
	char data;
}Node;
Node* createNewNode(char data);
int push(Node* head, char data);
char pop(Node** head);
void printStack(Node* head);
#endif