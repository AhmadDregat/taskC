#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "Stack.h"
Node* stack = NULL;

bool isStringBalanced(char** sentence, int size)
{
	int countparent = 0;
	for(int j = 0; j < size; j++)
	{
		char* string= sentence[j];
		int sLength = strlen(string );
		for (int i = 0; i < sLength; ++i) {
			printf("%c" ,string[i]);


			if((string[i] == '(')||(string[i] == '{')||(string[i] == '['))
			{
				countparent++;
				if(stack != NULL)
				push(stack, string[i]);
				else
				{
					stack = createNewNode(string[i]);	
				}}
		
			if((string[i] == ')'))
			{
				char parent = pop(&stack);
				if(parent != '(')
					return false;
				countparent--;
			}
			if((string[i] == ']'))
			{
				char parent= pop(&stack);
				if(parent != '[')
					return false;
				countparent--;
			}
			if((string[i] == '}'))
			{
				char parent = pop(&stack);
				if(parent != '{')
					return false;
				countparent--;
			}
		}
	}
	if(countparent != 0)
		return false;
	printf("\n%d",countparent);

	return true;
}


int main(void) 
{
char *s[2];

scanf("%s", *s);
	if(isStringBalanced(s,1))
	{
	 puts("\n Balanced");
	}
	else
	{	puts("\nnot Balanced");
	 
		
	}
	return 0;
}