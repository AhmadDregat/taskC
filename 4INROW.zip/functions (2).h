#include <stdio.h>
#define Row 6 // Rows
#define Col 7 //coloumns

	int checkWin(char b[Row][Col]);
	void Undo(char board[Row][Col], int steps[42], int i);
	void allTogether(char board[Row][Col], int col, char player, int count, int steps[42]);
	int lastMove(char board[Row][Col], int steps[42], int count);
	int emptyPlace(char board[Row][Col], int col);
int inRange(int col);
int checkMove(char board[Row][Col], int col, char player, int steps[42], int i);
void scanMove(int col);
void Configureboard(char board[Row][Col]);
void IsTurn(char player);
int isFilled(char arr[Row][Col]);
