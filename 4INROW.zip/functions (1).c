#include <stdio.h>
#include "functions.h"
#define Row 6 
#define Col 7 
	void Configureboard(char board[Row][Col])
{
	for (int i = 0; i<Row; i++)
	{
		for (int j = 0; j<Col; j++)
		{
			board[i][j] = ' ';
		}
	}
}

void IsTurn(char player)
{
	printf("\nPlayer %c, please enter a column number (or 0 to undo):\n", player);
	return;
}
void printBoard(char board[Row][Col])
{
	for (int i = 0; i<Row; i++)
	{
		for (int j = 0; j<Col; j++)
		{
			printf("|%c", board[i][j]);
		}
		printf("|\n");

	}
	printf("---------------\n");
	for (int i = 1; i<Col + 1; i++)
		printf(" %d", i);
		printf("\n");
}
void Undo(char board[Row][Col], int steps[42], int i)
{
	if (i>0)
	{
		board[lastMove(board, steps, i)][steps[i]] = ' ';

	}
}
void scanMove(int col)
{
	scanf("%d", &col);
	
}


void allTogether(char board[Row][Col], int col, char player, int count, int steps[42])
{
	count = -1;
	int valid = checkMove(board, col, player, steps, count);
	while (valid != 1)
	{
		scanf("%d", &col);
		checkMove(board, col, player, steps, count);
	}
	count++;


}

int lastMove(char board[Row][Col], int steps[42], int count)
{
	int laststep = 0, i;
	for (i = 0; i<Row; i++)
	{
		if (board[i][steps[count]] != ' ')
		{
			laststep = i;
			return laststep;
		}
	}
	return laststep;
}

int emptyPlace(char board[Row][Col], int col)
{
	int row = -1;
	int i;
	for (i = 0; i<Row; i++)
	{
		if (board[i][col - 1] == ' ') row++;
	}
	return row;
}
int inRange(int col)
{
	if (col >= 1 && col <= 7) 
	  
	  return 1;


	return 0;
}

int checkMove(char board[Row][Col], int col, char player, int steps[42], int i)
{
	int range = 0;
	IsTurn(player);
	scanf("%d", &col);
	int row = emptyPlace(board, col);
	range = inRange(col);
	if (col == 0&&i!=0)
	{
		Undo(board, steps, i);
		printBoard(board);
		return 1;
	}else printf("Board is empty - can't undo!");
	if (row == -1)
	{
		printf("Invalid move. Column  is full.\nPlease try again:");
		return -2; // invalid
	}
	if (range == 0)
	{

		return 0;  

	}
	int cell = emptyPlace(board, col);

	board[cell][col - 1] = player;
	printf("%d\n", col);
	if (col != 0) {
		steps[i] = col;
		i++;
	}
	printBoard(board);
	return 1;     

}

  int isFilled(char arr[Row][Col])
{
	int i, j;

	for (i = 0; i < Row; i++)
	{
		for (j = 0; j < Col; j++)
		{
			if (arr[i][j] == ' ')
				return 0;
		}
	}
	return 1;
}
int checkWin(char b[Row][Col])
{
	int i, j;  
	int retVal = 0;  


	for (i = 0; i < Row; i++)
	{
		if (b[i][0] != ' ' && b[i][0] == b[i][1] && b[i][1] == b[i][2] && b[i][2] == b[i][3])
			retVal = 1;
		else if (b[i][1] != ' ' && b[i][1] == b[i][2] && b[i][2] == b[i][3] && b[i][3] == b[i][4])
			retVal = 1;
		else if (b[i][2] != ' ' && b[i][2] == b[i][3] && b[i][3] == b[i][4] && b[i][4] == b[i][5])
			retVal = 1;
		else if (b[i][3] != ' ' && b[i][3] == b[i][4] && b[i][4] == b[i][5] && b[i][5] == b[i][6])
			retVal = 1;
	}
	for (j = 0; j < Col; j++)
	{
		if (b[0][j] != ' ' && b[0][j] == b[1][j] && b[1][j] == b[2][j] && b[2][j] == b[3][j])
			retVal = 1;
		else if (b[1][j] != ' ' && b[1][j] == b[2][j] && b[2][j] == b[3][j] && b[3][j] == b[4][j])
			retVal = 1;
		else if (b[2][j] != ' ' && b[2][j] == b[3][j] && b[3][j] == b[4][j] && b[4][j] == b[5][j])
			retVal = 1;
	}
	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			if (b[i][j] != ' ' && b[i][j] == b[i + 1][j + 1] && b[i + 1][j + 1] == b[i + 2][j + 2] && b[i + 2][j + 2] == b[i + 3][j + 3])
				retVal = 1;
		}
	}
	for (i = 1; i < 4; i++)
	{
		for (j = 6; j > 2; j--)
		{
			if (b[i][j] != ' ' && b[i][j] == b[i + 1][j - 1] && b[i + 1][j - 1] == b[i + 2][j - 2] && b[i + 2][j - 2] == b[i + 3][j - 3])
				retVal = 1;
		}
	}
	for (i = 1; i < 5; i++)
	{
		for (j = 0; j < 4; j++)
		{
			if (b[i][j] != ' ' && b[i][j] == b[i + 1][j + 1] && b[i + 1][j + 1] == b[i + 2][j + 2] && b[i + 2][j + 2] == b[i + 3][j + 3])
				retVal = 1;
		}
	}
	for (i = 1; i < 5; i++)
	{
		for (j = 6; j > 2; j--)
		{
			if (b[i][j] != ' ' && b[i][j] == b[i + 1][j - 1] && b[i + 1][j - 1] == b[i + 2][j - 2] && b[i + 2][j - 2] == b[i + 3][j - 3])
				retVal = 1;
		}
	}
	for (i = 2; i < 6; i++)
	{
		for (j = 0; j < 4; j++)
		{
			if (b[i][j] != ' ' && b[i][j] == b[i + 1][j + 1] && b[i + 1][j + 1] == b[i + 2][j + 2] && b[i + 2][j + 2] == b[i + 3][j + 3])
				retVal = 1;
		}
	}
	for (i = 2; i < 6; i++)
	{
		for (j = 6; j > 2; j--)
		{
			if (b[i][j] != ' ' && b[i][j] == b[i + 1][j - 1] && b[i + 1][j - 1] == b[i + 2][j - 2] && b[i + 2][j - 2] == b[i + 3][j - 3])
				retVal = 1;
		}
	}
	return retVal;
}