
#include <stdio.h>
#include "functions.h"
#define Row 6 
#define Col 7 


int main()
{
    printf(" Welcome!\n\n");
    
	int col = 0, i = 0;
	char board[Row][Col], player = 'O';
	int steps[42] = { 0 };

	Configureboard(board);
	printBoard(board);
	while (1) {

		if (player == 'X')
		{
			player = 'O';
		}
		else
		{
			player = 'X';
		}
		checkMove(board, col, player, steps, i);
		printf("\nsteps %d\n", steps[i]);
		i++;
	
	  if (checkWin(board))
			{
				printf("\nPLAYER %c WINS!\n\n",player);
				break;
			}
			if (isFilled(board))
			{
				printf("It's a tie !!!\n\n");
				break;
			}
	}
	
	return 0;
}
