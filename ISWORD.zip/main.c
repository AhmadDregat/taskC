#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
typedef int bool;
#define true 1
#define false 0
#include "func.h"
#define size 4
#define MATRIX_SIZE 4
int main()
{
    char mat[4][4] = {
      {'C', 'A', 'R', 'T'},
      {'E', 'T', 'A', 'K'}, 
      {'E', 'S', 'M', 'E'}, 
      {'L', 'L', 'P', 'N'}
      
    };
    int i,j,*x,x1;
    printf("The matrix is: \n\n");
    for(i=0;i<MATRIX_SIZE;i++){
      printf("\n");
        for(j=0;j<MATRIX_SIZE;j++){
            printf("| %c |", mat[i][j]);
        }
    }
        printf("\n");
    printWords(mat);
    return 0;
}

int printWords(char A[MATRIX_SIZE][MATRIX_SIZE])
{
    bool mat[MATRIX_SIZE][MATRIX_SIZE] = {0};
    TAKE(A, mat);
}

void TAKE(char let[MATRIX_SIZE][MATRIX_SIZE], bool test[MATRIX_SIZE][MATRIX_SIZE])
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            char word[8] = {'\0'};
            char val[2] = {let[i][j], '\0'};
            strcat(word, val);
            if (i == 0)
            {
                bool mat1[MATRIX_SIZE][MATRIX_SIZE] = {0};
                memcpy(mat1, test, MATRIX_SIZE *MATRIX_SIZE * sizeof(bool));
                mat1[i][j] = true;
                if (j == 0)
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i + 1, j, word);
                }
                else if (j == 3)
                {
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i + 1, j, word);
                }
                else
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i + 1, j, word);
                }
            }
            else if (i == 1)
            {
                bool mat1[MATRIX_SIZE][MATRIX_SIZE] = {0};
                memcpy(mat1, test, MATRIX_SIZE * MATRIX_SIZE * sizeof(bool));
                mat1[i][j] = true;
                if (j == 0)
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i + 1, j, word);
                    cword(let, mat1, i - 1, j, word);
                }
                else if (j == 3)
                {
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i + 1, j, word);
                    cword(let, mat1, i - 1, j, word);
                }
                else
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i + 1, j, word);
                    cword(let, mat1, i - 1, j, word);
                }
            }
            else if (i == 2)
            {
                bool mat1[MATRIX_SIZE][MATRIX_SIZE] = {0};
                memcpy(mat1, test, MATRIX_SIZE * MATRIX_SIZE * sizeof(bool));
                mat1[i][j] = true;
                if (j == 0)
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i + 1, j, word);
                    cword(let, mat1, i - 1, j, word);
                }
                else if (j == 3)
                {
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i + 1, j, word);
                    cword(let, mat1, i - 1, j, word);
                }
                else
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i + 1, j, word);
                    cword(let, mat1, i - 1, j, word);
                }
            }
            else if (i == 3)
            {
                bool mat1[MATRIX_SIZE][MATRIX_SIZE] = {0};
                memcpy(mat1, test, MATRIX_SIZE * MATRIX_SIZE * sizeof(bool));
                mat1[i][j] = true;
                if (j == 0)
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i - 1, j, word);
                }
                else if (j == 3)
                {
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i - 1, j, word);
                }
                else
                {
                    cword(let, mat1, i, j + 1, word);
                    cword(let, mat1, i, j - 1, word);
                    cword(let, mat1, i - 1, j, word);
                }
            }
        }
    }
    printf("\nEND 20 words");
    }
char cword(char let[MATRIX_SIZE][MATRIX_SIZE], bool mat[MATRIX_SIZE][MATRIX_SIZE], int x, int y, char word[])
{
  
    char word1[17] = {'\0'};
    strcpy(word1, word);
    bool mat1[4][4] = {0};
    memcpy(mat1, mat, MATRIX_SIZE * MATRIX_SIZE * sizeof(bool));
    if (!mat1[x][y] && (x > -1 && y > -1 && x < size && y < size) && strlen(word1) < 8)
    {
        char val[2] = {let[x][y], '\0'};
        strcat(word1, val);
            mat1[x][y] = true;
            if (isWord(word1))
            {
            printf("- %s\n", word1);
            }
            if (x == 0)
            {
                if (y == 0)
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                }
                else if (y == 3)
                {
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                }
                else
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                }
            }
            else if (x == 1)
            {
                if (y == 0)
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
                else if (y == 3)
                {
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
                else
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
            }
            else if (x == 2)
            {
                if (y == 0)
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
                else if (y == 3)
                {
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
                else
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x + 1, y, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
            }
            else if (x == 3)
            {
                if (y == 0)
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
                else if (y == 3)
                {
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
                else
                {
                    cword(let, mat1, x, y + 1, word1);
                    cword(let, mat1, x, y - 1, word1);
                    cword(let, mat1, x - 1, y, word1);
                }
            }
        }
    }

bool isWord(char *s)
{
    return (!strcmp(s, "CAT") |
            !strcmp(s, "CATS") |
            !strcmp(s, "TRAM") |
            !strcmp(s, "TRAMS") |
            !strcmp(s, "TAME") |
            !strcmp(s, "CAR") |
            !strcmp(s, "CARS") |
            !strcmp(s, "RAT") |
            !strcmp(s, "RATS") |
            !strcmp(s, "RAMP") |
            !strcmp(s, "ART") |
            !strcmp(s, "CART") |
            !strcmp(s, "STAMP") |
            !strcmp(s, "TAKEN") |
            !strcmp(s, "MEN") |
            !strcmp(s, "MAKE") |
            !strcmp(s, "TAKE") |
            !strcmp(s, "ATE") |
            !strcmp(s, "SELL") |
            !strcmp(s, "STEEL") |
            !strcmp(s, "RAKE"));
}
