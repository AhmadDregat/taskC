typedef int bool;
#define true 1
#define false 0
#define size 4
#define wordlen 16
static char words[20][6] = {'\0'};
static int c = 0;

bool isWord(char* s);
int printWords(char A[4][4]);
void checkMat(char ltrs[4][4], bool mat[4][4]);
char checkWord(char ltrs[4][4], bool mat[4][4], int row, int column, char word[]);
void addWord(char word[]);
void print();
void TAKE(char let[4][4], bool test[4][4]);
char cword(char let[4][4], bool mat[4][4], int x, int y, char word[]);